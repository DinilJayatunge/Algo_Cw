import java.util.*;
public class DirectedGraph { // Task 2 define all data structures
    private final int numOfVertices;
    private final Map<String, Set<String>> adjacencyList;
    public DirectedGraph(int vertices) {
        this.numOfVertices = vertices;
        this.adjacencyList = new HashMap<>();
    }
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DirectedGraph:\n");
        for (Map.Entry<String, Set<String>> entry : adjacencyList.entrySet()) {
            builder.append(entry.getKey()).append(" -> ").append(entry.getValue()).append("\n");
        }
        return builder.toString();
    }
    public Map<String, Set<String>> getAdjacencyList() {
        return adjacencyList;
    }
    public void insertVertex(String vertex) {
        adjacencyList.put(vertex, new HashSet<>());
    }
    public void insertEdge(String u, String v) {
        adjacencyList.get(u).add(v);
    }
    public Set<String> getAdjacentVertices(String vertex) {
        return adjacencyList.get(vertex);
    }
    public int getTotalVertices() {
        return numOfVertices;
    }
    public void deleteVertex(String vertex) {
        adjacencyList.remove(vertex);
        adjacencyList.values().forEach(edges -> edges.remove(vertex));
    }
    public boolean isGraphEmpty() {
        for (Set<String> neighbors : adjacencyList.values()) {
            if (!neighbors.isEmpty()) {
                return false;
            }
        }
        return true;
    }
}