import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class GraphUtilities {
    public static DirectedGraph parseGraphFromFile(String file) throws IOException { // Task 3 reading graph from input file
        Set<String> vertexSet = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String u = String.valueOf(line.charAt(0));
                String v = String.valueOf(line.charAt(1));
                vertexSet.add(u);
                vertexSet.add(v);
            }
        }
        int vertexCount = vertexSet.size();
        DirectedGraph graph = new DirectedGraph(vertexCount);
        for (String vertex : vertexSet) {
            graph.insertVertex(vertex);
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String u = String.valueOf(line.charAt(0));
                String v = String.valueOf(line.charAt(1));
                graph.insertEdge(u, v);
            }
        }
        return graph;
    }
    public static boolean checkAcyclic(DirectedGraph graph) { // Task 4 check whether graph is acyclic or not
        while (true) {
            boolean sinkFound = false;

            for (String vertex : graph.getAdjacencyList().keySet()) {
                if (graph.getAdjacentVertices(vertex).isEmpty()) {
                    sinkFound = true;
                    System.out.println("Removing sink: " + vertex);
                    graph.deleteVertex(vertex);
                    break;
                }
            }
            if (!sinkFound) {
                return false;
            }
            if (graph.isGraphEmpty()) {
                return true;
            }
            System.out.println("Current graph: " + graph);
        }
    }
    public static List<String> detectCycle(DirectedGraph graph) { // Task 5 if not acyclic find and output cycle
        Map<String, Boolean> visited = new HashMap<>();
        List<String>
                cyclePath = new ArrayList<>();

        for (String vertex : graph.getAdjacencyList().keySet()) {
            if (!visited.getOrDefault(vertex, false)) {
                if (dfs(graph, vertex, null, visited, cyclePath)) {
                    return constructCycle(cyclePath, cyclePath.get(cyclePath.size() - 1));
                }
            }
        }
        return new ArrayList<>();
    }
    private static boolean dfs(DirectedGraph graph, String vertex, String parent, Map<String, Boolean> visited, List<String> cycle) {
        visited.put(vertex, true);
        cycle.add(vertex);
        for (String neighbor : graph.getAdjacentVertices(vertex)) {
            if (!visited.getOrDefault(neighbor, false)) {
                if (dfs(graph, neighbor, vertex, visited, cycle)) {
                    return true;
                }
            } else if (!neighbor.equals(parent)) {
                cycle.add(neighbor);
                return true;
            }
        }
        cycle.remove(cycle.size() - 1);
        return false;
    }
    private static List<String> constructCycle(List<String> cycle, String start) {
        List<String> result = new ArrayList<>();
        boolean inCycle = false;

        for (String vertex : cycle) {
            if (vertex.equals(start)) {
                inCycle = !inCycle;
            }
            if (inCycle) {
                result.add(vertex);
            }
        }
        // Add the starting vertex again to show the cycle is complete
        result.add(start);
        return result;
    }
}