import java.io.IOException;
import java.util.List;

public class EntryPoint  {
    public static void main(String[] args) {
        String file = "input.txt";
        try {
            System.out.println("Reading graph from input file...");
            DirectedGraph graph = GraphUtilities.parseGraphFromFile(file);
            System.out.println("Graph read successfully!");

            System.out.println("Checking if the graph is acyclic...");
            boolean isAcyclic = GraphUtilities.checkAcyclic(graph);
            System.out.println("Check completed.");

            if (isAcyclic) {
                System.out.println("The graph is acyclic.");
            } else {
                System.out.println("The graph is not acyclic.");
                System.out.println("Finding a cycle in the graph...");
                List<String> cycle = GraphUtilities.detectCycle(graph);
                System.out.println("Cycle found: " + cycle);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}